import geopandas as gpd
import fiona
from ..geom.line import Line

# class Road(Line):
#     gpd.io.file.fiona.drvsupport.supported_drivers["KML"] = "rw"
#     roads = gpd.read_file()

# class RoadNetwork:
#     _PATH_TO_ROAD_NETWORK = join(dirname(__file__), "assets/singapore-elevation.png")
    
#     @classmethod
#     def _get_roads(cls) -> Dict[str, Road]:
#         pass
