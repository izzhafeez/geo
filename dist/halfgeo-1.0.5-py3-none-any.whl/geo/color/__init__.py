import color.color

__all__ = ["color"]